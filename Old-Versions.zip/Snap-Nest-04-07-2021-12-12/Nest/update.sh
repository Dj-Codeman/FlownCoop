#! /bin/bash

curl https://www.audubonnest.tk/Total.php >> /dev/null
curl https://www.audubonnest.tk/classmanagment.php >> /dev/null
curl https://www.audubonnest.tk/class_reset.php >> /dev/null
