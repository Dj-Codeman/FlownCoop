<?php
$array = array();
for ($i=0; $i<1000; $i++)
{

  $db = mysqli_connect('192.168.0.3', 'Client', 'Y&0E1{8u){S?', 'Nest');
   $UID = MD5(uniqid());
   echo $UID;
   echo "</br>";
   $query = "UPDATE LoggedEvents SET uid = '$UID' WHERE id = '$i' ";
   mysqli_query($db, $query);
}

echo 'DONE';
?>
